const express = require('express');
const user = express();
const path= require('path');


user.set('views', path.join(__dirname, 'views'));
user.set('views engine', 'pug');

//route for Home Page
user.get('/', function(req, res){
    res.render(path.join(__dirname,"/views/homePage.pug"))
})

user.get('/homePage.pug', function(req, res){
    res.render(path.join(__dirname,"/views/homePage.pug"))
})

//route for Contact form
user.get('/contact.pug', function(req, res){
    res.render(path.join(__dirname,"/views/contact.pug"))
})

//listen for request on port...
user.listen(50000, function(){
    console.log("Listening at port 50000")
})